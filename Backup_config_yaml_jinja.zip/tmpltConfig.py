from netmiko import ConnectHandler
import threading

user = input('Enter username : ')
passwd = input('Enter password : ')

def tmpltsshThread(user, passwd):
	thread = []
	for line in open('ip.csv'):
		ip = line.split(',')[0].strip('\n')
		nodename = line.split(',')[1].strip('\n')
		print(nodename)
		device = {'host': ip, 'device_type': 'arista_eos', 'username': user, 'password': passwd}
		th = threading.Thread(target=tmpltsshConfig, args=(device,nodename))
		th.start()
		thread.append(th)
	
	for th in thread:
		th.join()

def tmpltsshConfig(device,nodename):
	sshConnect = ConnectHandler(**device)
	prompt = sshConnect.find_prompt()
	hostname = prompt[:-1]
	pre_config_file = nodename+'_pre_config.conf'
	print(pre_config_file)
	f1 = open(pre_config_file, 'w+')
	pre_config = sshConnect.send_command('show run')
	f1.write(pre_config)
	f1.close()
	conf_file = nodename + '.conf'
	print(conf_file)
	activity_log = sshConnect.send_config_from_file(conf_file)
	verification = []
	for cmd in open('verification_cmd.txt'):
		output = sshConnect.send_command(cmd)
		verification.append(output)
	post_config_file = nodename+'_post_config.conf'
	f2 = open(post_config_file, 'w+')
	post_config = sshConnect.send_command('show run')
	print(post_config)
	f2.write(post_config)
	f2.close()
	print(activity_log)
	print(verification)
	sshConnect.disconnect()

tmpltsshThread(user, passwd)
	