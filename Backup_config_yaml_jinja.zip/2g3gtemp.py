import yaml
from jinja2 import Environment,FileSystemLoader

env = Environment(loader=FileSystemLoader('c:/Personal/python/NetDevOps/jinja2'))

template = env.get_template('switchConf.j2')

for line in open('ip.csv'):
	yaml_file = line.split(',')[1].strip('\n')+'.yaml'
	conf_file = line.split(',')[1].strip('\n')+'.conf'
	
	with open(yaml_file) as y:
		host_obj = yaml.load(y, Loader=yaml.SafeLoader)
		f = open('c:/Personal/python/NetDevOps/netmiko/' + conf_file, 'w')
		config = template.render(host=host_obj)
		print(config)
		f.write(config)
		f.close()
		print()